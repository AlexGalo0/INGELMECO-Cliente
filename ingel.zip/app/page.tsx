import React from "react";

import Search from "./components/Search";

const Productos: React.FC = () => {
  return (<Search />);
};

export default Productos;
